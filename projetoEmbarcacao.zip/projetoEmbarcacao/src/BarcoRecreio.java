public class BarcoRecreio extends Embarcacao{
    
    protected int qtdRedes;

    public BarcoRecreio(String nome, int capacidade, double velocidade, int qtdRedes) {
        super(nome, capacidade, velocidade);
        this.qtdRedes = qtdRedes;
    }

    @Override 
    public String exibirInfo(){
        return super.exibirInfo()+" | Redes |=> "+this.qtdRedes;
    }
}
