public class Lancha extends Embarcacao{

    protected int potenciaMotor;

    public Lancha(String nome, int capacidade, double velocidade, int potenciaMotor) {
        super(nome, capacidade, velocidade);
        this.potenciaMotor = potenciaMotor;
    }

    @Override 
    public double tempoViagem(double km){
        return (km/super.velocidade) + potenciaMotor;
    }

    @Override 
    public String exibirInfo(){
        return super.exibirInfo()+" | Potência Motor |=> "+this.potenciaMotor;
    }
}


//interface e polimorfismo