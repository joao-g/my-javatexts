public class App {
    public static void main(String[] args) throws Exception {
        
        Embarcacao e = new Embarcacao("Embarcação", 40, 50);
        Lancha l = new Lancha("Lancha", 30, 40, 10);
        BarcoRecreio br = new BarcoRecreio("Barco Recreio", 10, 20, 100);
        Balsa b  = new Balsa("Balsa", 30, 10, 100);

        System.out.println(e.exibirInfo());
        System.out.println(l.exibirInfo());
        System.out.println(br.exibirInfo());
        System.out.println(b.exibirInfo());
    }
}
