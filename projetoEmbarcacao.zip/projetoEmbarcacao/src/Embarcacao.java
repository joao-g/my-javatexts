public class Embarcacao {
    
    protected  String nome;
    protected  int capacidade;
    protected  double velocidade;

    public Embarcacao(String nome, int capacidade, double velocidade) {
        this.nome = nome;
        this.capacidade = capacidade;
        this.velocidade = velocidade;
    }

    public double tempoViagem(double km){
        return km/velocidade;
    }

    public String exibirInfo(){
        return " | Nome |=> "+this.nome+" | Capacidade |=> "+this.capacidade+" | Velocidade |=> "+this.velocidade;
    }
}
