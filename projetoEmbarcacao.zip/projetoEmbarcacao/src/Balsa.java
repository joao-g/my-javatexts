public class Balsa extends Embarcacao{
    
    protected double cargaMaxima;

    public Balsa(String nome, int capacidade, double velocidade, double cargaMaxima) {
        super(nome, capacidade, velocidade);
        this.cargaMaxima = cargaMaxima;
    }

    @Override 
    public String exibirInfo(){
        return super.exibirInfo()+" | Carga Máxima |=> "+this.cargaMaxima;
    }
}
    
