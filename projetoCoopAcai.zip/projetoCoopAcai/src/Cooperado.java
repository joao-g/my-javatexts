public class Cooperado {

    protected String nome;
    protected String matricula;                           
    protected double valorBase;

    public Cooperado(String nome, String matricula, double valorBase) {
        this.nome = nome;
        this.matricula = matricula;
        this.valorBase = valorBase;
    }

    public double calcularPagamento() {
        return this.valorBase;
    }

    public String exibirResumo() {
        return "| Nome |=> "+this.nome+" | Matricula |=> "+this.matricula+" | Valor |=> "+this.calcularPagamento();
    }
}
