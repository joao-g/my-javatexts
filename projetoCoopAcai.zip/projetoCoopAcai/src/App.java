public class App {
    public static void main(String[] args) throws Exception {

        Cooperado c = new Cooperado("Cooperado", "m01", 10);
        Peconheiro p = new Peconheiro("Peçonheiro", "m02", 10, 100);
        Batedor b = new Batedor("Batedor", "m03", 10, 100);

        System.out.println(c.exibirResumo());
        System.out.println(p.exibirResumo());
        System.out.println(b.exibirResumo());
    }
}
