public class Peconheiro extends Cooperado{

    protected int rasasColhidas;

    public Peconheiro(String nome, String matricula, double valorBase, int rasasColhidas) {
        super(nome, matricula, valorBase);
        this.rasasColhidas = rasasColhidas;
    }
    
    @Override 
    public double calcularPagamento() {
        return super.calcularPagamento()+(15*this.rasasColhidas);
    }
}
