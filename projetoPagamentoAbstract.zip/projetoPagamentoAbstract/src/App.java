
import java.util.ArrayList;

public class App {
    public static void main(String[] args) throws Exception {
        
        ArrayList<Pagamento> pagamentos = new ArrayList<>();

        Pagamento pix = new Pix(200);
        pagamentos.add(pix);

        Pagamento cartao = new Cartao(200);
        pagamentos.add(cartao);

        Pagamento boleto = new Boleto(200);
        pagamentos.add(boleto);

        double total = 0;
        for (Pagamento p : pagamentos) {
            p.info();
            total += p.calcularTotal();
        }
        System.out.println("TOTAL | "+total);
        System.out.println("=".repeat(20));
    }
}
