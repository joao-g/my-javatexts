public class Boleto extends Pagamento {

    public Boleto(double valor) {
        super(valor);
    }

    @Override
    double calcularTotal() {
        if (this.valor >= 10) {
            return valor-10;
        } else {
            return valor;
        }
    }

    @Override
    void info() {
        System.out.println("=".repeat(20));
        System.out.println("MÉTODO | BOLETO");
        System.out.println("VALOR  | "+this.calcularTotal());
        System.out.println("=".repeat(20));
    }
}
