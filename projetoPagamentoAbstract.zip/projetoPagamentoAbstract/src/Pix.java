public class Pix extends Pagamento {

    public Pix(double valor) {
        super(valor);
    }

    @Override
    double calcularTotal() {
        return this.valor*0.95;
    }

    @Override
    void info() {
        System.out.println("=".repeat(20));
        System.out.println("MÉTODO | PIX");
        System.out.println("VALOR  | "+this.calcularTotal());
        System.out.println("=".repeat(20));
    }
}
