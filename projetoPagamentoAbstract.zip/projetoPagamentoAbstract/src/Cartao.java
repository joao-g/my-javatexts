public class Cartao extends Pagamento {

    public Cartao(double valor) {
        super(valor);
    }

    @Override
    double calcularTotal() {
        return this.valor*1.08;
    }

    @Override
    void info() {
        System.out.println("=".repeat(20));
        System.out.println("MÉTODO | CARTÃO");
        System.out.println("VALOR  | "+this.calcularTotal());
        System.out.println("=".repeat(20));
    } 
}
