public abstract class Pagamento {
    
    protected double valor;

    public Pagamento(double valor) {
        this.valor = valor;
    }

    abstract double calcularTotal();

    abstract void info();
}
