public class Sms extends Notificacao {

    public Sms(String destinatario) {
        super(destinatario);
    }
    
    @Override 
    public void enviar() {
        System.out.println("Mensagem enviada por SMS para "+destinatario);
    }
}
