public class WhatsApp extends Notificacao {

    public WhatsApp(String destinatario) {
        super(destinatario);
    }
    
    @Override 
    public void enviar() {
        System.out.println("Mensagem enviada por WhatsApp para "+destinatario);
    }
}
