public class App {
    public static void main(String[] args) throws Exception {

        System.out.println("=".repeat(20));

        Notificacao e = new Email("João");
        e.enviar();

        System.out.println("=".repeat(20));

        Notificacao s = new Sms("Julyane");
        s.enviar();

        System.out.println("=".repeat(20));

        Notificacao w = new WhatsApp("Kali");
        w.enviar();

        System.out.println("=".repeat(20));
    }
}
