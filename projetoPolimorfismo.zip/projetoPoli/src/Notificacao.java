public abstract class Notificacao {
    
    protected String destinatario;

    public Notificacao(String destinatario) {
        this.destinatario = destinatario;
    }

    abstract void enviar();
}
